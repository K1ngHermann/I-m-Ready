#!/bin/sh

yarn seeds
