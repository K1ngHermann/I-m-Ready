sleep 10 && gh codespace ports visibility 3000:public -c $CODESPACE_NAME
